import React from "react";
import Home from "./Pages/Home";
import SignUp from "./Components/SignUp";
import Login from "./Components/Login";
import DetailProduct from "./Pages/DetailProduct";
import {
    BrowserRouter as Router,
    Routes,
    Route,
    Navigate,
} from "react-router-dom";

function App() {
	
		return (
			<>
				<Router>
					<Routes>
						<Route path="/" element={<Home/>}></Route>
						<Route path="/detail/:id" element={<DetailProduct/>}></Route>
						<Route path="/signup" element={<SignUp/>}></Route>
						<Route path="/login" element={<Login/>}></Route>
						<Route
								path="*"
								element={<Navigate to="/" />}
							/>
					</Routes>
				</Router>
			</>
		);
	
}

export default App;

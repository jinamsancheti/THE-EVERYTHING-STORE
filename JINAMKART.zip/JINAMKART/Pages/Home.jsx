import React from "react";
import Navbar from "../Components/Navbar";
import Hero from "../Components/Hero";
import Card from "../Components/Card";
import data from "../data";

const cardData = data.map((cData) => {
	return (
		<Card
			key={cData.id}
			{...cData}
		/>
	);
});

function Home() {
	return (
		<div>
			<Navbar />
			<div className="main">
				<Hero/>	
				<div className="row-cards">
					<div className="Card-items">
						{cardData}
					</div>
					<div className="Card-items">
						{cardData}
					</div>
					<div className="Card-items">
						{cardData}
					</div>
					<div className="Card-items">
						{cardData}
					</div>
					<div className="Card-items">
						{cardData}
					</div>
				</div>
			</div>
		</div>
	);
	
}

export default Home;
